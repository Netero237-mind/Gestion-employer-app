from django.apps import AppConfig


class EmployeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'employe'
    verbose_name = "Gestion des Employés"
